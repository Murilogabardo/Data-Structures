#pragma once

#include "Arvore.h"

class Akinator
{
private:
	Arvore A1;
public:
	Akinator(void);
	~Akinator(void);

	void executar();
};

