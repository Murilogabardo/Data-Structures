#include "StdAfx.h"
#include "Akinator.h"


Akinator::Akinator(void)
{
	executar();
}


Akinator::~Akinator(void)
{

}

void Akinator::executar(void)
{
	/*Folhas*/
	No NCha("Cha");
	No NSuco("Suco");
	No NAgua("Agua");
	No NRefri("Refri");
	No NLeite("Leite");
	No NAchocolatado("Achocolatado");
	No NVitamina("Vitamina", NULL, NULL);
	No NYakult("Leite fermentado com lactobacilos vivos");
	No NIogurte("Iogurte");
	No NSaque("Saque");
	No NVinho("Vinho");
	No NCerveja("Cerveja");
	No NChampagne("Champagne");
	No NPinga("Pinga");
	No NTequila("Tequila");
	No NVodka("Vodka");
	No NRum("Rum");
	No NWhisky("Whisky");
	No NConhaque("Conhaque");
	No NAmarula("Licor de Amarula");
	No NEncontrado("Realmente sou paraguaio! Nao encontro sua bebida em minha extensa lista!");

	No NEscuro1("E escuro?", &NLeite, &NAchocolatado);
	No NSabores("Tem varios sabores", &NYakult, &NIogurte);
	No NGelado ("Eh consumido gelado?", &NCha, &NSuco);
	No NInodoro("Eh inodoro?", &NGelado, &NAgua);
	No Nfrutas("Bate com frutas?", &NEscuro1, &NVitamina);
	No NSaude("Faz bem aa sa�de", &NRefri, &NInodoro);
	No NBacteria("Envolve bacterias em sua producao", &Nfrutas, &NSabores);
	No NAnimal("Tem origem animal?", &NSaude, &NBacteria);
	
	
	No NRequintado("E requintado", &NCerveja, &NChampagne);
	No NNorte("E do Hemisferio Norte?", &NPinga, &NTequila);
	No NEuropeia("E de origem europeia", &NNorte, &NVodka);
	No NPVinho("E feito a partir do vinho?", &NEncontrado,&NConhaque);
	No NEuropeia2("Tem origem escocesa?", &NPVinho, &NWhisky);
	No NPirata("E conhecida como bebida de piratas?", &NEuropeia2, &NRum);
	No NDoce("E doce?", &NPirata, &NAmarula);
	No NEscuro3 ("E escuro?", &NSaque, &NVinho);
	No NEscuro2("E escuro?", &NEuropeia, &NDoce);
	No NEspuma("Faz espuma?", &NEscuro3, &NRequintado);
	No NDestilado("E destilado?", &NEspuma, &NEscuro2);


	/*Raiz*/
	No NAlcolica("E alcolica?", &NAnimal, &NDestilado);

	A1.adicionarRaiz(&NAlcolica);

	cout<<"Bem vindo ao Akinator paraguaio sobre bebidas!"<<endl<<"Pense fortemente em uma bebida e entao responda aas minhas perguntas"<<endl;

	int resposta;

	No* pAtual = A1.getRaiz();

	do
	{
		cout<<pAtual->getInfo()<<endl<<"0 - Nao, 1 - Sim: ";

		cin>>resposta;

		while(resposta != 0 && resposta != 1)
		{
			"Opcao invalida";
		}
		
		if(resposta == 0)
		{
			pAtual = pAtual->getEsquerda();
		}
		else if(resposta == 1)
		{
			pAtual = pAtual->getDireita();
		}

	}while(pAtual->getDireita()||pAtual->getEsquerda());


	system("cls");

	if(pAtual)
		cout<<"A bebida em que voce pensa certamente e: "<<pAtual->getInfo()<<endl;



	system("pause");

	exit (0);
}
