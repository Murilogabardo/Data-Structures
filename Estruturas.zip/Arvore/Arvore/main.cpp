// Arvore.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "Akinator.h"

int _tmain(int argc, _TCHAR* argv[])
{

	Akinator AK1;

	AK1.executar();

	return 0;
}

