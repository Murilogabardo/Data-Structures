#pragma once

#include "No.h"
#include "stdafx.h"

class Arvore
{
private:
	No* raiz;
	No* pAux;

public:
	Arvore(void);
	~Arvore(void);

	void adicionar(string cInfo, No* pEsq, No* pDir);
	void adicionar(No* pNo);
	void imprimir() const;

	No* getRaiz() const;
	void adicionarRaiz(No* pNo);

};

