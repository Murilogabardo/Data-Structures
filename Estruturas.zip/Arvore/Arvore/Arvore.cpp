#include "StdAfx.h"
#include "Arvore.h"


Arvore::Arvore(void)
{
	raiz = NULL;
}


Arvore::~Arvore(void)
{

}

void Arvore::adicionar(string cInfo, No* pEsq, No* pDir)
{

}

void Arvore::adicionar(No* pNo)
{
	if(raiz == NULL)
	{
		raiz = pNo;
	}
	else
	{
		
	}
}
void Arvore::imprimir() const
{

}

No* Arvore::getRaiz() const
{
	return raiz;
}

void Arvore::adicionarRaiz(No* pNo)
{
	if(!raiz)
	{
		raiz = pNo;
	}
}
