#pragma once

#include "stdafx.h"

class No
{
private:
	string info;
	No* direita;
	No* esquerda;
public:
	No(const string cInfo = "", No* pEsq = NULL,No* pDir = NULL);
	~No(void);

	void setDireita(No* pDir);
	void setEsquerda(No* pEsq);

	No* getDireita() const;
	No* getEsquerda() const;

	string getInfo() const;
};

