#include "StdAfx.h"
#include "No.h"


No::No(const string cInfo, No* pEsq, No* pDir)
{
	info = cInfo;
	direita = pDir;
	esquerda = pEsq;
}




No::~No(void)
{

}

void No::setDireita(No* pDir)
{
	direita = pDir;
}

void No::setEsquerda(No* pEsq)
{
	esquerda = pEsq;
}

No* No::getDireita() const
{
	return direita;
}

No* No::getEsquerda() const
{
	return esquerda;
}

string No::getInfo() const
{
	return info;
}
