#include "Num.h"
#include "Menux.h"


Num::Num(void)
{
	pProx = NULL;
	pAnt = NULL;
}

Num::Num(double N)
{
	pProx = NULL;
	pAnt = NULL;
	numero = N;
}


Num::~Num(void)
{

}

void Num::setNumero(double N)
{
	numero = N;
}

double Num::getNumero() const
{
	return numero;
}

void Num::setProx(Num* pP)
{
	pProx = pP;
}

Num* Num::getProx() const
{
	return pProx;
}

void Num::setAnt(Num* pA)
{
	pAnt = pA;
}

Num* Num::getAnt() const
{
	return pAnt;
}


