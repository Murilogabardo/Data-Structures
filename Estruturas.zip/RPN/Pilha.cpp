#include "Pilha.h"
#include <conio.h>


Pilha::Pilha(void)
{
	pPrimeiro = NULL;
	pAux = NULL;
	tamanho = 0;
}


Pilha::~Pilha(void)
{
}

void Pilha::incluir(double N)
{

	if(!pPrimeiro)
	{
		pPrimeiro = new Num(N);
	}
	else
	{
		pAux = pPrimeiro;

		pPrimeiro = new Num(N);
		pPrimeiro->setProx(pAux);
		pPrimeiro->setAnt(NULL);

		pAux->setAnt(pPrimeiro);
	}

	tamanho++;
}

void Pilha::excluir()
{
	pAux = pPrimeiro->getProx();
	if(pAux)
		pAux->setAnt(NULL);
	delete pPrimeiro;
	pPrimeiro = pAux;
	tamanho--;
}

void Pilha::listar()
{
	pAux = pPrimeiro;
	
	if(pPrimeiro)
	{
		while(pAux->getProx())
		{
			pAux = pAux->getProx();
		}

		do
		{
			cout<<pAux->getNumero()<<endl;
			pAux = pAux->getAnt();
		}while(pAux);
	}
}

int Pilha::getTamanho() const
{
	return tamanho;
}

Num* Pilha::getPrimeiro() const
{
	return pPrimeiro;
}

bool Pilha::isNumero(string N) 
{
	int i;
	char c;

	for(i = 0; i < N.size(); i++)
	{	
		c = N[i];

		if(  !(((0x39 >= c) && (c >= 0x30)||c == 0x2E)  || (((c == 0x2D || c == 0x2B)&&(i==0)&&N.size() >= 2))) )
		{
			return false;
		}
	}

	return true;
}
