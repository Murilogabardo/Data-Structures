#pragma once

class Num
{
private:
	double numero;
	Num* pProx;
	Num* pAnt;
public:
	Num(void);
	Num(double N);
	~Num(void);

	void setNumero(double N);
	double getNumero() const;

	void setProx(Num* pP);
	Num* getProx() const;

	void setAnt(Num* pA);
	Num* getAnt() const;
};

