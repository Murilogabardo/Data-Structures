#pragma once

#include "stdafx.h"
#include "Pilha.h"

class Menux
{
private:
	string dado;
	double dadonumerico;
	Pilha P1;
	double Num1;
	double Num2;
	double Num3;

public:
	Menux(void);
	~Menux(void);

	void executar();
};

