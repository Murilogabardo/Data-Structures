#pragma once

#include "stdafx.h"
#include "Num.h"

class Pilha
{
private:
	Num* pPrimeiro;
	Num* pAux;
	int tamanho;
public:
	Pilha(void);
	~Pilha(void);

	void incluir(double N);
	void excluir();
	void listar();

	int getTamanho() const;

	Num* getPrimeiro() const;

	bool isNumero(string N);
};

