#include "Menux.h"


Menux::Menux(void)
{
}


Menux::~Menux(void)
{
}

void Menux::executar(void)
{
	cout<<"Digite as instrucoes e digite exit para sair: "<<endl;

	do
	{
		fflush(stdin);
	
		cin>>dado;

		if((dado == "+" || dado == "-" || dado == "*" || dado == "/")&&P1.getTamanho() >= 2)
		{
			Num1 = P1.getPrimeiro()->getNumero();
			Num2 = P1.getPrimeiro()->getProx()->getNumero();

			if(dado == "+")
			{
				Num3 = Num2 + Num1;
			}
			else if (dado == "-")// && P1.getTamanho() >= 2)
			{
				Num3 = Num2 - Num1;
			}
			else if (dado == "*")// && P1.getTamanho() >= 2)
			{
				Num3 = Num2 * Num1;
			}
			else if (dado == "/")// && P1.getTamanho() >= 2)
			{
				if(!(-1*std::numeric_limits<double>::min()< Num1 && Num1 < std::numeric_limits<double>::min()))
				{
					Num3 = Num2 / Num1;
				}
				else
				{
					cout<<"Divis�o por zero n�o permitida"<<endl<<endl;
					system("pause");
					Num3 = Num2;
				}
			}

			P1.excluir();
			P1.excluir();
			P1.incluir(Num3);
		}
		else if(P1.isNumero(dado))
		{
			P1.incluir(std::stof(dado));
		}

		system("cls");
		cout<<"Digite as instrucoes e digite exit para sair: "<<endl;
		P1.listar();
	}while(dado != "exit");

}
