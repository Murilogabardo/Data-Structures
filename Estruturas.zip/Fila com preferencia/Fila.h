#pragma once

#include "Pessoa.h"
#include "ElementoPessoa.h"

class Fila
{
private:
	ElementoPessoa* pPrimeiro;
	ElementoPessoa* pUltimo;
	ElementoPessoa* pEAux;
	Pessoa* pPAux;

	int tamanho;

public:
	Fila(void);
	~Fila(void);

	void incluir(Pessoa* pP);
	void excluir();
	void listar();
	Pessoa* chamar() const;
	int getTamanho() const;

	void imprimir(Pessoa* pP);

};

