#include "StdAfx.h"
#include "Filacomprioridade.h"


Filacomprioridade::Filacomprioridade(void)
{
}


Filacomprioridade::~Filacomprioridade(void)
{
}

void Filacomprioridade::incluir(string nome, unsigned int idade, bool gestante, const bool especial)
{
	if((gestante || especial) || (idade > 60))
	{
		Prioritaria.incluir(new Pessoa(nome, idade, gestante, especial));
	}
	else
	{
		Normal.incluir(new Pessoa(nome, idade, gestante, especial));
	}
}

void Filacomprioridade::excluir()
{
	if(Prioritaria.getTamanho() > 0)
	{
		Prioritaria.excluir();
	}
	else if(Normal.getTamanho()>0)
	{
		Normal.excluir();
	}
}
void Filacomprioridade::listar()
{
	cout<<"----------------Fila prioritaria-----------------------"<<endl<<endl;
	Prioritaria.listar();
	cout<<endl;

	cout<<"-------------------Fila normal----------------------"<<endl<<endl;
	Normal.listar();
	cout<<endl;

}


Pessoa* Filacomprioridade::chamar() const
{
	if(Prioritaria.getTamanho() > 0)
	{
		return Prioritaria.chamar();
	}
	else if(Normal.getTamanho()>0)
	{
		return Normal.chamar();
	}
	else
	{
		return NULL;
	}
}

void Filacomprioridade::imprimir(Pessoa* pP)
{
	Normal.imprimir(pP);
}