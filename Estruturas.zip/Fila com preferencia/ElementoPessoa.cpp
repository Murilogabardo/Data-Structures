#include "StdAfx.h"
#include "ElementoPessoa.h"


ElementoPessoa::ElementoPessoa(Pessoa* pA)
{
	pProximo = NULL;
	pAnterior = NULL;
	pAnexo = pA;
}


ElementoPessoa::~ElementoPessoa(void)
{
}

void ElementoPessoa::setAnexo (Pessoa* pP)
{
	pAnexo = pP;
}

Pessoa* ElementoPessoa::getAnexo() const
{
	return pAnexo;
}

void ElementoPessoa::setProximo(ElementoPessoa* pP)
{
	pProximo = pP;
}

ElementoPessoa* ElementoPessoa::getProximo() const
{
	return pProximo;
}

void ElementoPessoa::setAnterior(ElementoPessoa* pP)
{
	pAnterior = pP;
}

ElementoPessoa* ElementoPessoa::getAnterior() const
{
	return pAnterior;
}
