#include "StdAfx.h"
#include "Fila.h"


Fila::Fila(void)
{
	pPrimeiro = NULL;
	pUltimo = NULL;
	tamanho = 0;
}


Fila::~Fila(void)
{
}

int Fila::getTamanho() const
{
	return tamanho;
}


void Fila::incluir(Pessoa* pP)
{
	if(!pPrimeiro)
	{
		pEAux = new ElementoPessoa(pP);
		pPrimeiro = pEAux;
		pUltimo = pEAux;
	}
	else
	{
		pEAux = pUltimo;
		pUltimo = new ElementoPessoa(pP);
		pUltimo->setProximo(pEAux);
		pEAux->setAnterior(pUltimo);
	}
	tamanho++;
}

void Fila::excluir()
{
	if(tamanho > 0)
	{
		if(pUltimo == pPrimeiro)
		{
			pEAux = pUltimo;
			pUltimo = NULL;
			pPrimeiro = NULL;
		}
		else
		{
			pEAux = pPrimeiro;
			pPrimeiro = pPrimeiro->getAnterior();
			pPrimeiro->setProximo(NULL);
		}

		delete pEAux;
		tamanho--;
	}

}
void Fila::listar() 
{
	pEAux = pPrimeiro;
	int i = 1;

	if(tamanho > 0)
	{
		do
		{
			cout<<i<<" - ";
			imprimir(pEAux->getAnexo());

			pEAux = pEAux->getAnterior();

			i++;

		}while(pEAux);

	}
	else
	{
		cout<<"N�o existem pessoas nessa fila";
	}

}

Pessoa* Fila::chamar() const
{
	return pPrimeiro->getAnexo();
}

void Fila::imprimir(Pessoa* pP)
{
		cout<<"Nome: "<<pP->getNome()<<" - Idade: "<<pP->getIdade();

		if(pP->isEspecial())
		{
			cout<< " - Portador de Necessidades Especiais";
		}
			
		if(pP->isGestante())
		{
			cout<<  " - Gestante";
		}

		cout<<endl;
}