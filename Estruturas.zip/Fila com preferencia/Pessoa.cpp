#include "StdAfx.h"
#include "Pessoa.h"

Pessoa::Pessoa(string N, unsigned int I , bool G, bool E):
especial(E)
{
	nome = N;
	idade = I;
	gestante = G;
}


Pessoa::~Pessoa(void)
{
}

void Pessoa::setNome(string N)
{
	nome = N;
}
string Pessoa::getNome() const
{
	return nome;
}

void Pessoa::setIdade(unsigned int I)
{
	idade = I;
}

unsigned int Pessoa::getIdade() const
{
	return idade;
}

void Pessoa::setGestante(bool G)
{
	gestante = G;
}
bool Pessoa::isGestante() const
{
	return gestante;
}

const bool Pessoa::isEspecial() const
{
	return especial;
}

	
