#include "StdAfx.h"
#include "Menux.h"


Menux::Menux(void)
{
}


Menux::~Menux(void)
{
}

void Menux::executar(void)
{



	do
	{
		cout<<"Selecione uma opcao: "<<endl;
		cout<<"0 - Sair"<<endl;
		cout<<"1 - Incluir nova pessoa na fila"<<endl;
		cout<<"2 - Chamar pessoa da fila"<<endl;
		cout<<"3 - Mostrar a fila"<<endl<<endl;


		fflush(stdin);

		cin>>op;

		system("cls");

		switch (op)
		{
			case 0:
				return;
			break;
			case 1:
				incluir();
				break;
			case 2:
				chamar();
				break;
			case 3:
				listar();
				break;
			default:
				cout<<endl<<"Opcao invalida";
				break;
			}


		system("cls");
	

	}while(op);

}

void Menux::incluir()
{
	string nome;
	unsigned int idade;
	bool especial = false;
	bool gestante = false;
	int resposta;

	cout<<"Nome: ";
	cin>>nome;

	cout<<endl<<"Idade: ";
	cin>>idade;

	do
	{
		cout<<endl<<"E portador de necessidades especiais? 1 - Sim, 2 - Nao ";
		cin>>resposta;

		if(resposta == 1)
		{
			especial = true;
		}

	}while(resposta != 2 && resposta != 1);

	do
	{
		cout<<endl<<"E gestante? 1 - Sim, 2 - Nao ";
		cin>>resposta;
		if(resposta == 1)
		{
			gestante = true;
		}

	}while(resposta != 2 && resposta != 1);

	F.incluir(nome, idade, gestante, especial);
}

void Menux::chamar()
{
	Pessoa* pAux;
	pAux = F.chamar();
	if(pAux)
	{
		cout<<"O proximo da fila e: "<<endl<<endl;
		F.imprimir(pAux);
		F.excluir();
	}
	else
	{
		cout<<"Nao existem pessoas em nenhuma das filas"<<endl<<endl;
	}

	system("pause");
}

void Menux::listar()
{
	F.listar();

	cout<<endl;

	system("pause");
}