#pragma once
class Pessoa
{
private:
	string nome;
	unsigned int idade;
	const bool especial;
	bool gestante;

public:
	Pessoa(string N = "", unsigned int I = 0, bool G = false, bool E = false);
	~Pessoa(void);

	void setNome(string N);
	string getNome() const;

	void setIdade(unsigned int I);
	unsigned int getIdade() const;

	void setGestante(bool G);
	bool isGestante() const;

	const bool isEspecial() const;
	
};

