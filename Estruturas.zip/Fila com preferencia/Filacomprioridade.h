#pragma once

#include "Pessoa.h"
#include "Fila.h"

class Filacomprioridade
{
private:
	Fila Normal;
	Fila Prioritaria;

public:
	Filacomprioridade(void);
	~Filacomprioridade(void);

	void incluir(string nome, unsigned int idade, bool gestante, const bool especial);
	void excluir();
	void listar();
	void imprimir(Pessoa* pP);
	Pessoa* chamar() const;
};

