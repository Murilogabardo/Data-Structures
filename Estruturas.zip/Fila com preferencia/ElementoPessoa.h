#pragma once
#include "Pessoa.h"

class ElementoPessoa
{
	Pessoa* pAnexo;
	ElementoPessoa* pProximo;
	ElementoPessoa* pAnterior;

public:
	ElementoPessoa(Pessoa* pA = NULL);
	~ElementoPessoa(void);

	void setAnexo (Pessoa* pP);
	Pessoa* getAnexo() const;

	void setProximo(ElementoPessoa* pP);
	ElementoPessoa* getProximo() const;

	void setAnterior(ElementoPessoa* pP);
	ElementoPessoa* getAnterior() const;
};

