#pragma once

#include "Pessoa.h"
#include "Filacomprioridade.h"

class Menux
{
private:
	Filacomprioridade F;

	int op;

public:
	Menux(void);
	~Menux(void);
	void executar(void);

	void incluir();
	void chamar();
	void listar();
};

