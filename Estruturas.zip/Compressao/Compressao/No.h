#pragma once

#include "stdafx.h"

class No
{
private:
	string palavra;
	int peso;

	No* direita;
	No* esquerda;

public:
	No(const string cValor = " ", const int cPeso = 1, No* pEsq = NULL, No* pDir = NULL);
	No(No* pNo);
	~No(void);

	void setDireita(No* pDir);
	void setEsquerda(No* pEsq);

	No* getDireita() const;
	No* getEsquerda() const;

	string getPalavra() const;
	int getPeso() const;

	void increasePeso();
	void decreasePeso();
	void setPeso(const int N);
	void setPalavra(const string S);


};

