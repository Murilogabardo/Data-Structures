#include "StdAfx.h"
#include "No.h"


No::No(const string cValor, const int cPeso, No* pEsq, No* pDir)
{
	palavra = cValor;
	peso = cPeso;
	direita = pEsq;
	esquerda = pDir;

}

No::No(No* pNo)
{
	palavra = pNo->getPalavra();
	peso = pNo->getPeso();
	direita = pNo->getDireita();
	esquerda = pNo->getEsquerda();
}

No::~No(void)
{

}

void No::setDireita(No* pDir)
{
	direita = pDir;
}

void No::setEsquerda(No* pEsq)
{
	esquerda = pEsq;
}

No* No::getDireita() const
{
	return direita;
}

No* No::getEsquerda() const
{
	return esquerda;
}

string No::getPalavra() const
{
	return palavra;
}

void No::setPalavra(const string S)
{
	palavra = S;
}

void No::increasePeso()
{
	peso++;
}
void No::decreasePeso()
{
	peso--;
}

int No::getPeso() const
{
	return peso;
}

void No::setPeso(const int N)
{
	peso = N;
}