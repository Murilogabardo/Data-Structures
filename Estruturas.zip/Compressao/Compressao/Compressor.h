#pragma once

#include "No.h";

class Compressor
{
private:
	ifstream Texto;
	char pAux[500];
	string sAux;
	char cAux[2];
	int index;
	vector<No*> vetorHuffman;
	map<string*, string*> mapaDecodificacao;
	string codigo;
	No* raiz;
	int tamanhooriginal;
	std::vector<No*>::iterator it;
	string Comprimido;
	std::map<string*,string*>::iterator itx;
	ofstream Arquivo;
	

public:
	Compressor(string caminho = "");
	~Compressor(void);

	void montarVetor();
	bool isPontuacao(char cC);
	void adicionarVetor(char* cS);
	void montarArvore();
	void montarDecodifica��o();
	void percorreArvore(No* pNo, int comprimento);
	void codifica();
	string procurarMapa(string cS);
	void salva(string local);
};

