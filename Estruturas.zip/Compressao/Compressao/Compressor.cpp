#include "StdAfx.h"
#include "Compressor.h"


Compressor::Compressor(string caminho):
Texto(caminho)
{
	tamanhooriginal = 0;
	cAux[1] = '\0';
}


Compressor::~Compressor(void)
{
}

void Compressor::montarVetor()
{
	if(Texto.is_open())
	{
		while(!Texto.eof())
		{
			index = 0;
			while( (cAux[0] = Texto.get()) != ' ' && cAux[0] != '\n' && !isPontuacao(cAux[0]))
			{
					if(!Texto.eof())
					{
						pAux[index] = cAux[0];
						index++;
					}
					else
					{
						break;
					}
			}

			pAux[index] = '\0';

			if(pAux[0] != '\0')
			{
				tamanhooriginal += index;
				adicionarVetor(pAux);
			}

			if(!Texto.eof())
			{
				tamanhooriginal += 1;
				adicionarVetor(cAux);
			}
			else
			{
				break;
			}
		}

		cout<<"Bytes originais do texto: "<<tamanhooriginal<<endl;

	}
	else
	{
		cout<<"Nao abriu";
	}
}

bool Compressor::isPontuacao(char cC)
{
	if(
		cC =='.' || cC == ',' || cC =='!'|| cC == '1' 
		|| cC == ':' || cC == '[' || cC == ']' 
		|| cC == '{' || cC == '}' || cC == '(' 
		|| cC == '\'' || cC == '"' || cC == ';'
		|| cC == '?' || cC == '\\' || cC == '|'
	  )
	{
		return true;
	}
	else
	{
		return false;
	}
}

void Compressor::adicionarVetor(char* cS)
{
	int i;
	bool incluir = true;
	for(it = vetorHuffman.begin(); it != vetorHuffman.end(); it++)
	{
		if(!(*it)->getPalavra().compare(cS))
		{
			(*it)->increasePeso();
			incluir = false;
			break;
		}
	}

	if(incluir)
	{
		vetorHuffman.push_back(new No(cS));
	}
}

void Compressor::montarArvore()
{
	int min;
	No* nomin1, *nomin2, *pJunt, *pAux1, *pAux2;

	nomin1 = nomin2 = *vetorHuffman.begin();

	min = (*vetorHuffman.begin())->getPeso();

	std::vector<No*>::iterator it1, it2;

	while(vetorHuffman.size() > 2)
	{

		min = (*vetorHuffman.begin())->getPeso();
		nomin1 = (*vetorHuffman.begin());
		it1 = vetorHuffman.begin();

		for(it =vetorHuffman.begin(); it != vetorHuffman.end(); it++)
		{
			if((*it)->getPeso() < min)
			{
				min = (*it)->getPeso();
				nomin1 = (*it);
				it1 = it;
			}
		}

		pAux1 = new No(nomin1);
		vetorHuffman.erase(it1);

		min = (*vetorHuffman.begin())->getPeso();
		nomin2 = (*vetorHuffman.begin());
		it2 = vetorHuffman.begin();

		for(it = vetorHuffman.begin(); it != vetorHuffman.end(); it++)
		{
			if((*it)->getPeso() < min ||
				((*it)->getPeso() == min && (*it)->getDireita() && (*it)->getEsquerda()))
			{
				min = (*it)->getPeso();
				nomin2 = (*it);
				it2 = it;
			}
		}

		pAux2 = new No(nomin2);
		vetorHuffman.erase(it2);

		pJunt = new No(pAux1->getPalavra() + pAux2->getPalavra() + '\0'
						,pAux1->getPeso() + pAux2->getPeso()
						,pAux2
						,pAux1
					  );
		
		vetorHuffman.push_back(pJunt);

	}
	pAux1 = vetorHuffman[0];
	pAux2 = vetorHuffman[1];

	raiz = new No(pAux1->getPalavra() + pAux2->getPalavra()
					,pAux1->getPeso() + pAux2->getPeso()
					,pAux2
					,pAux1);
}

void Compressor::montarDecodifica��o()
{
	percorreArvore(raiz, 0);

	int i;
	for(itx = mapaDecodificacao.begin(); itx != mapaDecodificacao.end(); itx++)
	{
		cout<<"Palavra: "<<*(itx->first)<<endl<<"Codigo: "<<*(itx->second)<<endl<<endl;
	}

}

void Compressor::percorreArvore(No* pNo, int comprimento)
{
  if(pNo != NULL)
  {
    if(pNo->getEsquerda() == NULL &&  pNo->getDireita() == NULL)
    {
	  mapaDecodificacao.insert(std::pair<string*,string*>(new string(pNo->getPalavra()),new string(codigo)));
	  codigo += '0';
      return;
    }
	codigo += '0';
	percorreArvore(pNo->getEsquerda(), comprimento+1);
	codigo[comprimento] = '1';
    percorreArvore(pNo->getDireita(), comprimento+1);
  }
}

void Compressor::codifica()
{
	Texto.clear();
	Texto.seekg (0, Texto.beg);
	Comprimido = "";
	while(!Texto.eof())
	{
		sAux = "";
		while( (cAux[0] = Texto.get()) != ' ' && cAux[0] != '\n' && !isPontuacao(cAux[0]))
		{
			if(!Texto.eof())
			{
				sAux += cAux[0];
			}
			else
			{
				break;
			}
		}

		if(sAux != "")
		{
			Comprimido += procurarMapa(sAux);
		}

		if(!Texto.eof())
		{
			Comprimido += procurarMapa(cAux);
		}
		else
		{
			break;
		}
	}

	Texto.close();
}

string Compressor::procurarMapa(string cS)
{
	for(itx = mapaDecodificacao.begin(); itx != mapaDecodificacao.end(); itx++)
	{
		if((*(itx->first) == cS))
		{
			return *(itx->second);
		}
	}
}

void Compressor::salva(string local)
{
	Arquivo.open(local, std::ofstream::trunc | std::ofstream::binary);
	if(Arquivo.is_open())
	{
		int i,k;
		char ignorar;
		char byte;
		if(Comprimido.length()%8 != 0)
		{
			ignorar = 8 - Comprimido.length()%8;
			for(i = 0; i < ignorar; i++)
			{
				Comprimido += '0';
			}
		}

		Arquivo.write(&ignorar,1);

		for(k = 0; k < Comprimido.length(); k+=8)
		{
			byte = 0x00;
			for(i=0; i<8;i++)
			{
				if(Comprimido[i+k] == '1')
				{
					byte |= 0x01<<(7-i);	
				}
			}
			Arquivo.write(&byte,1);
		}

		Arquivo.close();
		cout<<"A taxa de compressao e: "<<(((1-(Comprimido.length()/8.0)/tamanhooriginal))*100.0)<<" por cento"<<endl;;

	}
	else
	{
		cout<<"Arquivo nao foi aberto";
	}
}
