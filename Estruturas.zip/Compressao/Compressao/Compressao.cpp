// Compressao.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Compressor.h"


int _tmain(int argc, _TCHAR* argv[])
{
	Compressor C1("ParaComprimir.txt");
	C1.montarVetor();
	C1.montarArvore();
	C1.montarDecodifica��o();
	C1.codifica();
	C1.salva("Compactado.dat");

	system("pause");
}

