// Iterativos.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


int _tmain(int argc, _TCHAR* argv[])
{
	int resposta;

	bool rodar = true;



	do
	{	
		
		cout<<"Escolha o programa que vossa senhoria gostaria de visualizar a pleno vapor: "<<endl
		<<"1 - Fatorial"<<endl
		<<"2 - Fibonacci"<<endl
		<<"0 - Sair"<<endl;

		cin>>resposta;
		
		system("cls");

		switch (resposta)
		{
		unsigned long long int resultado, anterior, i, aux;
		case 1:
			cout<<"Digite a posicao do numero de valores: "<<endl;

			cin>>resposta;

			resultado = 1;

			cout<<resultado<<" ";

			if(resposta == 1)
			{
				cout<<resultado<<" ";
			}

			if(resposta >= 2)
			{
				for(i = 2; i <=resposta; i++)
				{
					resultado *= i;
					cout<<resultado<< " ";
				}
			}

			system("pause");

			break;
		case 2:
			cout<<"Digite o comprimento da sequencia: "<<endl;

			cin>>resposta;	

			resultado = 0;

			cout<<resultado<< " ";

			if(resposta >= 1)
			{
				anterior = 0;
				resultado = 1;
				cout<<resultado<<" ";
				for(i = 2; i <= resposta; i++)
				{
					aux = resultado;
					resultado += anterior;
					anterior = aux;
					cout<<resultado<<" ";
				}
			}

			cout<<endl;

			system("pause");
			break;
		case 0:
			rodar = false;
			break;
		default: 
			cout<<"Op��o inv�lida"<<endl;
		}

		system("cls");

	}while(rodar);

	return 0;
}