// DoubleQueued.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Stack.h"
#include "List.h"
#include "Arvore.h"
#include "stdafx.h"


int _tmain(int argc, _TCHAR* argv[])
{
	Stack<float> S1;

	List<Arvore*> A1;

	S1.includeTop(5);
	S1.includeTop(10);
	S1.includeTop(10);
	S1.includeTop(15);
	S1.includeTop(10);
	S1.includeTop(17);
	S1.includeBottom(19);
	S1.includeBottom(15);

	S1.removeBottom();
	S1.removeTop();

	A1.includeTop(new Arvore);
	A1.includeTop(new Arvore);
	A1.includeTop(new Arvore);
	A1.includeTop(new Arvore);
	A1.includeTop(new Arvore);

	A1[0]->adicionar(5);
	A1[0]->adicionar(5);
	A1[0]->adicionar(5);
	A1[0]->adicionar(5);
	A1[0]->adicionar(5);
	A1[0]->adicionar(10);

	A1[1]->adicionar(5);
	A1[1]->adicionar(5);
	A1[1]->adicionar(5);
	A1[1]->adicionar(5);
	A1[1]->adicionar(5);
	A1[1]->adicionar(10);

	A1[2]->adicionar(5);
	A1[2]->adicionar(5);
	A1[2]->adicionar(5);
	A1[2]->adicionar(5);
	A1[2]->adicionar(5);
	A1[2]->adicionar(10);
	

    cout<<endl;
	cout<<endl;

    A1[0]->imprimir();
	A1[1]->imprimir();
	A1[2]->imprimir();

    cout<<endl<<"A esquerda do valor 4000 "<<A1[0]->contarElementosEsquerda(10);




	return 0;
}

