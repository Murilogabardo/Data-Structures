#pragma once
class Ordenador
{
public:
	Ordenador(void);
	~Ordenador(void);

	long long int atribuicoes;
	long long int comparacoes;


	void criarRandomico(short int *pV, long int tamanho);
	void buscar(short int *pV, long long int limite);
	void bolha(short int* pV, long long int limite, bool resetar);
	void outro(short int* pV, long long int limite);
	void outro2avinganca(short int* pV, long long int limite);
	void imprimir(short int *pV, long long int limite);

	long long int getAtribuicoes() const;
	long long int getComparacoes() const;
};

