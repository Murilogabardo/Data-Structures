// Ordena��o.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Menux.h"


int _tmain(int argc, _TCHAR* argv[])
{
	Menux M1;
	M1.executar();
	return 0;
}

