#include "StdAfx.h"

#include "Menux.h"

Menux::Menux(void)
{
}


Menux::~Menux(void)
{

}

void Menux::executar(void)
{
	int op;
	long int tamanho = sizeof(loja)/sizeof(short int);


	time_t tcomeco;
	time_t tfim;

	do
	{
		O1.criarRandomico(loja, tamanho);

		//O1.imprimir(loja,tamanho-1);

		cout<<"Digite a opcao pretendida: "<<endl;
		cout<<"1 - Procurar minimos sem ordenar: "<<endl;
		cout<<"2 - Procurar minimos ordenando com bolha"<<endl;
		cout<<"3 - Procurar minimos ordenando com o primeiro metodo"<<endl;
		cout<<"4 - Procurar minimos ordenando com o segundo metodo: a vinganca"<<endl;
		cout<<"5 - Sair do programa"<<endl<<endl;

		cin>>op;

		system("cls");

		cout<<"Ordenando...";

		time(&tcomeco);

		switch (op)
		{
			case 1:
				O1.buscar(loja, tamanho-1);
				break;

			case 2:
				O1.bolha(loja, tamanho-1, true);
				break;

			case 3:
				O1.outro(loja, tamanho-1);
				break;

			case 4:
				O1.outro2avinganca(loja, tamanho-1);
				break;

			case 5:
				exit(0);
		}

		time(&tfim);

		system("cls");

		cout<<"Tempo de execucao: "<<tfim - tcomeco<<" segundos"<<endl<<"Numero de comparacoes: "<<O1.getComparacoes()<<endl<<"Numero de atribuicoes: "<<O1.getAtribuicoes()<<endl;

		cout<<endl<<"Deseja imprimir os 1000 primeiros itens? 1 para sim e 0 para nao."<<endl;

		cin>>op;

		if(op == 1)
		{
			O1.imprimir(loja,tamanho-1);
		}

		system("pause");
		system("cls");



	}while(op);

}
