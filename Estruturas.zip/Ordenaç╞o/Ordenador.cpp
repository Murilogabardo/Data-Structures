#include "StdAfx.h"
#include "Ordenador.h"


Ordenador::Ordenador(void)
{
}


Ordenador::~Ordenador(void)
{
}

void Ordenador::criarRandomico(short int* pV, long int tamanho)
{
	int i;

	std::srand(std::time(0));

	for(i = 0; i < tamanho; i++)
	{
		pV[i] = std::rand()%255;
		//cout<<pV[i]<<endl;
	}

}

void Ordenador::buscar(short int *pV, long long int limite)
{


}

void Ordenador::bolha(short int* pV, long long int limite, bool resetar)
{
	bool mudou;
	long long int i;

	comparacoes = 0;
	atribuicoes = 0;

	do
	{
		mudou = false;

		for(i = 0; i < limite; i++)
		{
			comparacoes += 1;
			if(pV[i] > pV[i+1])
			{
				mudou = true;
				pV[i] += pV[i+1];
				pV[i+1] = pV[i] - pV[i+1];
				pV[i] = pV[i] - pV[i+1];
				atribuicoes += 3;
			}
		}
		
	}while(mudou);

	//imprimir(pV, limite);
}

void Ordenador::outro(short int* pV, long long int limite)
{

	comparacoes = 0;
	atribuicoes = 0;

	short int min;
	long long int iinferior;
	long long int isuperior;
	long long int itroca;

	iinferior = 0;

	while(iinferior <= limite)
	{
		min = pV[iinferior];
		for(isuperior = iinferior; isuperior <= limite; isuperior++)
		{
			comparacoes++;
			if(pV[isuperior] < min)
			{
				min = pV[isuperior];
				itroca = isuperior;
				atribuicoes += 2;
			}
		}
		pV[itroca] = pV[iinferior];
		pV[iinferior] = min;

		iinferior++;
		atribuicoes += 3;
	}
}

void Ordenador::outro2avinganca(short int* pV, long long int limite)
{
	comparacoes = 0;
	atribuicoes = 0;

	long long int iinferior = 1;
	long long int idinamico;

	while(iinferior <= limite)
	{
		//bolha(pV, iinferior, false);
		idinamico = iinferior;
		while((pV[idinamico - 1]>pV[idinamico])&& idinamico)
		{
			pV[idinamico-1] += pV[idinamico];
			pV[idinamico] = pV[idinamico-1] - pV[idinamico];
			pV[idinamico -1] = pV[idinamico - 1] - pV[idinamico];
			atribuicoes += 3;
			comparacoes += 2;
			idinamico--;
		}
		iinferior++;
	}

	//imprimir(pV,limite);

}

void Ordenador::imprimir(short int* pV, long long int limite)
{
	int i;

	for( i = 0; i <= limite; i++)
	{
		cout<<i<<" - R$"<<pV[i]<<endl;
	}


}


long long int Ordenador::getAtribuicoes() const
{
	return atribuicoes;
}
long long int Ordenador::getComparacoes() const
{
	return comparacoes;
}
