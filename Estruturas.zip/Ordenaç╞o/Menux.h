#pragma once

#include "Menux.h"
#include "Ordenador.h"


class Menux
{
private:
	Ordenador O1;
	short int loja[500000];

public:
	Menux(void);
	~Menux(void);

	void executar();
};

