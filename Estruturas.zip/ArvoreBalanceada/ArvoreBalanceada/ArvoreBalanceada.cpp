// ArvoreBalanceada.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Arvore.h"


int _tmain(int argc, _TCHAR* argv[])
{
	Arvore A1;

	A1.adicionar(17250);
	A1.adicionar(12100);
	A1.adicionar(64000);
	A1.adicionar(8277);
	A1.adicionar(5993);
	A1.adicionar(0);
	A1.adicionar(594);
	A1.adicionar(12500);
	A1.adicionar(1248);
	A1.adicionar(1796);
	A1.adicionar(15950);
	A1.adicionar(660);
	A1.adicionar(13500);
	A1.adicionar(9860);
	A1.adicionar(49);
	A1.adicionar(8226);
	A1.adicionar(7400);
	A1.adicionar(1600);
	A1.adicionar(8277);
	A1.adicionar(1689);
	A1.adicionar(4000);
	A1.adicionar(5998);
	A1.adicionar(40);
	A1.adicionar(5987);
	A1.adicionar(6064);
	A1.adicionar(2179);
	A1.adicionar(7540);
	A1.adicionar(299);
	A1.adicionar(3528);
	A1.adicionar(0);
	A1.adicionar(200);
	A1.adicionar(2110);


	A1.contagem();


	A1.imprimir();

	cout<<endl<<"Olha a info"<<A1.buscarCaminho(4000);
	cout<<endl<<"Olha a info"<<A1.buscarCaminho(2110);
	cout<<endl<<"Olha a info"<<A1.buscarCaminho(0);
	cout<<endl<<"Olha a info"<<A1.buscarCaminho(64000);

	cout<<endl<<"Buscando 660  "<<A1.buscar(4000)->getValor();
	cout<<endl<<"Contando o numero de elementos abaixo de 660  "<<A1.contarMenores(4000);


	cout<<endl<<endl<<A1.contarElementos();

	system("pause");

	return 0;
}

