#include "Lista.h"

Lista::Lista()
{
    pPrimeiro = NULL;
    pUltimo = NULL;
    pAux = NULL;
    pAux2 = NULL;
}

Lista::~Lista()
{

}

void Lista::incluir(string N)
{
    if(pPrimeiro == NULL)
    {
        pPrimeiro = new Passagem(N);
        pUltimo = pPrimeiro;
        cout<<"Passagem reservada  -  ";
        cout<<N<<" foi incluido"<<endl;
    }
    else
    {
        if(verificarreserva(N))
        {
            cout<<"Ja existe passagem reservada para"<<N<<endl;
        }
		else if(pPrimeiro == pUltimo)
		{
			if(N > pPrimeiro->getNome())
			{
				pUltimo = new Passagem(N);
			}
			else
			{
				pPrimeiro = new Passagem(N);
			}
			pPrimeiro->setProx(pUltimo);
			pPrimeiro->setAnt(pUltimo);

			pUltimo->setProx(pPrimeiro);
			pUltimo->setAnt(pPrimeiro);
			

		}
        else
        {
			ordenar(N);

            pAux->setProx(new Passagem(N));
			pAux2->setAnt(pAux->getProx());

			pAux->getProx()->setAnt(pAux);
			pAux->getProx()->setProx(pAux2);


            if(pAux2 == pPrimeiro)
				pUltimo = pAux2->getAnt();

			if(pAux2 == pUltimo)
				pPrimeiro = pAux2->getProx();

            cout<<"Passagem reservada  -  "<<N<<" foi incluido"<<endl;
        }

    }

}

void Lista::cancelar(string N)
{
    if(verificarreserva(N))
    {
        if(pPrimeiro == pUltimo)
        {
            delete pPrimeiro;
            pPrimeiro = NULL;
            pUltimo = NULL;
        }
        else
        {
            pAux = pPrimeiro;
            pAux2 = pPrimeiro->getProx();


            while(pAux->getNome() != N)
            {
                pAux = pAux->getProx();
                pAux2 = pAux->getProx();
            }

            if(pAux2->getProx() == pAux)
            {
                pAux2->setAnt(NULL);
                pAux2->setProx(NULL);
                pPrimeiro = pAux2;
                pUltimo = pAux2;
            }
            else
            {
                pAux->getAnt()->setProx(pAux2);
                pAux2->setAnt(pAux->getAnt());

                if(pAux == pPrimeiro)
                {
                    pPrimeiro = pAux2;
                }

                if(pAux == pUltimo)
                {
                    pUltimo = pAux->getAnt();
                }


            }
            delete pAux;
        }

        cout<<"Passagem cancelada"<<endl;
    }
    else
    {
        cout<<"N�o existem passagens reservadas em nome de "<<N<<endl;
    }

}

bool Lista::verificarreserva(string N)
{
    if(pPrimeiro)
    {
        pAux = pPrimeiro;

        while(pAux != pUltimo)
        {
            if(pAux->getNome() == N)
            {
                return true;
            }
            pAux = pAux->getProx();
        }

        if((pAux->getNome()) == N)
        {
            return true;
        }

        return false;
    }
    else
    {
        return false;
    }

}

void Lista::imprimir()
{
    int i = 1;

    pAux = pPrimeiro;

    if(pPrimeiro)
    {
        while(pAux != pUltimo)
        {
            cout<<i<<" - "<<pAux->getNome()<<endl;;
            pAux = pAux->getProx();
            i++;
        }

        cout<<i<<" - "<<pAux->getNome()<<endl;;
    }
    else
    {
        cout<<"N�o existem passagens reservadas!"<<endl;
    }


}

void Lista::ordenar(string N)
{
	pAux = pPrimeiro;
	pAux2 = pPrimeiro->getProx();

	while((N > pAux2->getNome())&& pAux2 != pPrimeiro)
	{
		pAux = pAux2;
		pAux2 = pAux2->getProx();
	}
}
