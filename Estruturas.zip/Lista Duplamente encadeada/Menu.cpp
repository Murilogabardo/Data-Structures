#include "Menu.h"

#include <stdlib.h>
#include <stdio.h>

Menu::Menu()
{
  op = 1;
}

Menu::~Menu()
{

}

void Menu::executar()
{
    string nome;


    while(op != 5)
    {
        system("cls");

        cout << "Digite o numero correspondente a sua escolha"<<endl;
        cout << "1 - Reservar passagem"<<endl;
        cout << "2 - Cancelar passagem"<<endl;
        cout << "3 - Verificar passagem"<<endl;
        cout << "4 - Imprimir lista de reservas"<<endl;
        cout << "5 - Sair do sistema"<<endl;
        cout<< endl;
        cin >> op;

        system("cls");

        switch (op)
        {
            case 1:
                cout<<"Digite o nome de quem quer reservar"<<endl<<endl;
                cin>>nome;
                cout<<endl;
                L1.incluir(nome);
                break;

            case 2:
                cout<<"Digite o nome de quem quer cancelar"<<endl<<endl;
                cin>>nome;
                cout<<endl;
                L1.cancelar(nome);
                break;

            case 3:
                cout<<"Digite o nome de quem quer verificar"<<endl<<endl;
                cin>>nome;
                cout<<endl;
                if(L1.verificarreserva(nome))
                {
                    cout<<nome<<" tem passagem reservada"<<endl<<endl;
                }

                break;

            case 4:
                cout<<"Lista de Reservas: "<<endl<<endl;
                L1.imprimir();
                break;
            case 5:
               exit(0);
            default:
                 cout<<"A opcao escolhida e invalida"<<endl;

        }
        cout<<endl;
        system("pause");
    }


}

