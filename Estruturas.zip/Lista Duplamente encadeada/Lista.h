#include "Passagem.h"
#include <iostream>
#include <string>

using std::cout;
using std::cin;
using std::endl;
using std::string;

class Lista
{
private:

    Passagem* pPrimeiro;
    Passagem* pUltimo;

    Passagem* pAux;
    Passagem* pAux2;

    Passagem Joao;

public:
    Lista();
    ~Lista();

    Passagem* getPrimeiro();
    void setPrimeiro(Passagem* pP);

    Passagem* getUltimo();
    void setUltimo(Passagem* pU);

    void incluir(string N);
    void cancelar(string N);
    bool verificarreserva(string N);
    void imprimir();
    void ordenar();

};
