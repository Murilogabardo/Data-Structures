#include <string>

using std::string;

class Passagem
{
private:
    string Nome;

    Passagem* pProx;
    Passagem* pAnt;

public:
    Passagem();
    Passagem(string N);
    ~Passagem();

    string getNome() const;
    void setNome(string N);

    void setProx(Passagem* pP);
    void setAnt(Passagem* pA);

    Passagem* getProx() const;
    Passagem* getAnt() const;

};
