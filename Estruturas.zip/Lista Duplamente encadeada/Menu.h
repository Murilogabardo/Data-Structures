#include "Lista.h"

#include<iostream>

using std::cout;
using std::endl;
using std::cin;

class Menu
{
private:

    int op;
    Lista L1;
public:
    Menu();
    ~Menu();

    void executar();

};
