#include "Passagem.h"

Passagem::Passagem()
{
    pProx = NULL;
    pAnt = NULL;
}

Passagem::Passagem(string N)
{
    pProx = NULL;
    pAnt = NULL;
    Nome = N;
}

Passagem::~Passagem()
{

}

string Passagem::getNome() const
{
    return Nome;
}

void Passagem::setNome(string N)
{
    Nome = N;
}



 void Passagem::setProx(Passagem* pP)
 {
     pProx = pP;
 }

 void Passagem::setAnt(Passagem* pA)
 {
     pAnt = pA;
 }

Passagem* Passagem::getProx() const
{
    return pProx;
}
Passagem* Passagem::getAnt() const
{
    return pAnt;
}
