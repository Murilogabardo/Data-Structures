#include "Lista.h"

Lista::Lista()
{
    pPrimeiro = NULL;
    pUltimo = NULL;
    pAux = NULL;
    pAux2 = NULL;
}

Lista::~Lista()
{

}

void Lista::incluir(string N)
{
    if(pPrimeiro == NULL)
    {
        pPrimeiro = new Passagem(N);
        pUltimo = pPrimeiro;
        cout<<"Passagem reservada  -  ";
        cout<<N<<" foi incluido"<<endl;
    }
    else
    {
        if(verificarreserva(N))
        {
            cout<<"Ja existe passagem reservada para"<<N<<endl;
        }
        else
        {
            pAux = new Passagem(N);

            pUltimo->setProx(pAux);

            pAux->setAnt(pUltimo);
            pAux->setProx(pPrimeiro);

            pPrimeiro->setAnt(pAux);

            pUltimo = pAux;

            cout<<"Passagem reservada  -  ";
            cout<<N<<" foi incluido"<<endl;
        }

    }

}

void Lista::cancelar(string N)
{
    if(verificarreserva(N))
    {
        if(pPrimeiro == pUltimo)
        {
            delete pPrimeiro;
            pPrimeiro = NULL;
            pUltimo = NULL;
        }
        else
        {
            pAux = pPrimeiro;
            pAux2 = pPrimeiro->getProx();


            while(pAux->getNome() != N);
            {
                pAux = pAux->getProx();
                pAux2 = pAux->getProx();
            }

            if(pAux2->getProx() == pAux)
            {
                pAux2->setAnt(NULL);
                pAux2->setProx(NULL);
                pPrimeiro = pAux2;
                pUltimo = pAux2;
            }
            else
            {
                pAux->getAnt()->setProx(pAux2);
                pAux2->setAnt(pAux->getAnt());

                if(pAux == pPrimeiro)
                {
                    pPrimeiro = pAux2;
                }

                if(pAux == pUltimo)
                {
                    pUltimo = pAux->getAnt();
                }


            }
            delete pAux;
        }

        cout<<"Passagem cancelada"<<endl;
    }
    else
    {
        cout<<"N�o existem passagens reservadas em nome de "<<N<<endl;
    }

}

bool Lista::verificarreserva(string N)
{
    if(pPrimeiro)
    {
        pAux = pPrimeiro;

        while(pAux != pUltimo)
        {
            string x = (*pAux).getNome();
            if(x == N)
            {
                return true;
            }
            pAux = pAux->getProx();
        }

        if((pAux->getNome()) == N)
        {
            return true;
        }

        return false;
    }
    else
    {
        return false;
    }

}

void Lista::imprimir()
{
    int i = 1;

    pAux = pPrimeiro;

    if(pPrimeiro)
    {
        while(pAux != pUltimo)
        {
            cout<<i<<" - "<<pAux->getNome()<<endl;;
            pAux = pAux->getProx();
            i++;
        }

        cout<<i<<" - "<<pAux->getNome()<<endl;;
    }
    else
    {
        cout<<"N�o existem passagens reservadas!"<<endl;
    }


}
