
#include "Menu.h"

int main()
{

    Menu M1;
    M1.executar();

    return 0;
}
