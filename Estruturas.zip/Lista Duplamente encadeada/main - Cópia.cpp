
#include <string>
#include <iostream>
#include <stdio.h>

using std::cout;
using std::string;

int main()
{
    char azul;

    fflush(stdin);

    azul = getchar();

    printf("%d %c", azul);

}
