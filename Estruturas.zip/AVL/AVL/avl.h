#ifndef AVL_H_INCLUDED
#define AVL_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct AVL_Node
{
    /*
     *  Estrutura do n� da �rvore AVL.
     *  Cont�m um bit extra que informa
     *  o grau de balanceamento da �rvore.
     *  Se for 0, 1 ou -1, a �rvore est�
     *  balanceada. Se n�o, ser�o realizadas
     *  algumas mudan�as at� que se balanceie
     */

     void *info;                // Informa��o contida no n�
     int bal;                   // Fator de balanceamento do n�

     struct AVL_Node *pai;      // Aponta para o n� ancestral
     struct AVL_Node *esq;      // Aponta para o filho da esquerda
     struct AVL_Node *dir;      // Aponta para o filho da direita

} AVL_Node;

typedef struct AVL_Tree
{
    /*
     *  Estrutura que define a �rvore AVL.
     *  Aonde est� guardada a raiz da �rvore.
     *  Cont�m ponteiros para fun��es que
     *  manipulam as informa��es contidas na
     *  �rvore.
     *
     *  A fun��o que o ponteiro compara_info
     *  aponta dever� retornar um valor inteiro
     *  segundo a seguinte legenda:
     *  +1 => Se o primeiro for maior
     *  -1 => Se o segundo for maior
     *   0 => Se os dois forem iguais
     */

     AVL_Node *root;            // Raiz da �rvore
     unsigned int num_nodes;    // N�mero de n�s da �rvore

     // Fun��o que compara duas informa��es
     int (*compara_info)( const void *, const void * );
     // Fun��o que imprime uma informa��o
     void (*imprime_info)( const void * );

} AVL_Tree;

/* Fun��es para manipula��o da �rvore */

// Inicializa��o da �rvore
void avl_init ( AVL_Tree **, int (*compara_info)( const void *, const void * ), void (*imprime_info)( const void * ));

// Insere um elemento na �rvore
int avl_insert ( AVL_Tree **, AVL_Node *, AVL_Node **, void * );

// Remove um elemento da �rvore
int avl_remove ( AVL_Tree **, AVL_Node **, void * );

// Realiza o percurso em pr�-ordem
void avl_walk_pre ( AVL_Tree *, AVL_Node * );

// Realiza o percurso em pos-ordem
void avl_walk_pos ( AVL_Tree *, AVL_Node * );

// Realiza o percurso em ordem simetrica
void avl_walk_sim ( AVL_Tree *, AVL_Node * );

// Realiza o percurso na �rvore por n�vel
void avl_walk_byLevel ( AVL_Tree * );

// Faz uma busca na �rvore
AVL_Node *avl_search ( AVL_Tree *, AVL_Node *, void * );

// Retorna a altura de uma sub-�rvore
int avl_height ( AVL_Node * );

#ifdef __cplusplus
}
#endif

#endif // AVL_H_INCLUDED
