#include "skiplist.h"
#include "avl.h"

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
