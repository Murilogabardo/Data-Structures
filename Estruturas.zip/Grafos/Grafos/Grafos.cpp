// Grafos.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "Grafo.h"
//#include "Cidade.h"


int _tmain(int argc, _TCHAR* argv[])
{
	Grafo G1;
	Cidade* pAux;

	Cidade PortoAlegre("Porto Alegre");
	Cidade Florianopolis("Florianopolis");
	Cidade Curitiba("Curitiba");
	Cidade CampoGrande("Campo Grande");
	Cidade Cuiaba("Cuiaba");
	Cidade SaoPaulo("Sao Paulo");
	Cidade Goiania("Goiania");
	Cidade BeloHorizonte("Belo Horizonte");
	Cidade RiodeJaneiro("Rio de Janeiro");
	Cidade PortoVelho("Porto Velho");
	Cidade RioBranco("RioBranco");
	Cidade Manaus("Manaus");
	Cidade BoaVista("BoaVista");
	Cidade Belem("Belem");
	Cidade Macapa("Macapa");
	Cidade Fortaleza("Fortaleza");
	Cidade Terezina("Terezina");
	Cidade SaoLuis("Sao Luis");
	Cidade Natal("Natal");
	Cidade JoaoPessoa("Joao Pessoa");
	Cidade Recife("Recife");
	Cidade Palmas("Palmas");
	Cidade Aracaju("Aracaju");
	Cidade Salvador("Salvador");
	Cidade Maceio("Maceio");


	//Porto Alegre
	G1.adicionarCidade(&PortoAlegre);
	G1.adicionarAdjascente(&PortoAlegre,"Florianopolis", 2336);
	
	//Floripa
	pAux = G1.adicionarCidade(&Florianopolis);
	G1.adicionarAdjascente(&Florianopolis,"Porto Alegre", 2336);
	G1.adicionarAdjascente(&Florianopolis,"Curitiba", 300);

	//Curitola
	G1.adicionarCidade(&Curitiba);
	G1.adicionarAdjascente(&Curitiba,"Florianopolis", 300);
	G1.adicionarAdjascente(&Curitiba,"Campo Grande", 991);
	G1.adicionarAdjascente(&Curitiba,SaoPaulo.getNome(), 408);

	//Campo Grande
	G1.adicionarCidade(&CampoGrande);
	G1.adicionarAdjascente(&CampoGrande,"Curitiba", 991);
	//G1.adicionarAdjascente(&CampoGrande,"Cuiaba", 694);
	G1.adicionarAdjascente(&CampoGrande,"Sao Paulo", 1014);
	//G1.adicionarAdjascente(&CampoGrande,"Goiania", 935);

	//S�o Paulo
	G1.adicionarCidade(&SaoPaulo);
	G1.adicionarAdjascente(&SaoPaulo,"Campo Grande", 1014);
	G1.adicionarAdjascente(&SaoPaulo,"Curitiba", 408);
	//G1.adicionarAdjascente(&SaoPaulo,"Rio de Janeiro", 429);
	//G1.adicionarAdjascente(&SaoPaulo,"Belo Horizonte", 586);

	//"Goiania"
	G1.adicionarCidade(&Goiania);

	//Belo Horizonte
	G1.adicionarCidade(&BeloHorizonte);

	//Rio de Janeiro
	G1.adicionarCidade(&RiodeJaneiro);

	//Porto Velho
	G1.adicionarCidade(&PortoVelho);

	G1.adicionarCidade(&RioBranco);
	G1.adicionarCidade(&Manaus);
	G1.adicionarCidade(&BoaVista);
	G1.adicionarCidade(&Belem);
	G1.adicionarCidade(&Macapa);
	G1.adicionarCidade(&Fortaleza);
	G1.adicionarCidade(&Terezina);
	G1.adicionarCidade(&SaoLuis);
	G1.adicionarCidade(&Natal);
	G1.adicionarCidade(&Recife);
	G1.adicionarCidade(&Palmas);
	G1.adicionarCidade(&Aracaju);
	G1.adicionarCidade(&Salvador);
	G1.adicionarCidade(&Maceio);



	int i, resposta, resposta2;

	cout<<"Selecione a cidade origem: "<<endl;

	for(i=0; i<G1.getNumeroCidades(); i++)
	{
		cout<<i<<" -"<< G1[i]->getNome()<<endl;
	}

	cin>>resposta;

	system("cls");


	cout<<"Agora selecione a cidade destino: "<<endl;

	for(i=0; i<G1.getNumeroCidades(); i++)
	{
		cout<<i<<" -"<<G1[i]->getNome()<<endl;
	}

	cin>>resposta2;

	G1.calcularDistanciasMinimas(G1[resposta]->getNome());
	G1.imprimirDistanciaMinima(G1[resposta2]->getNome());
	cout<<G1[resposta2]->getCaminho();



	system("Pause");



	return 0;
}

