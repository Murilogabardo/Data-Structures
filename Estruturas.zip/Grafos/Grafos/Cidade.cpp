#include "StdAfx.h"
#include "Cidade.h"
#include "math.h"




Cidade::Cidade(string N, float dist, List<Cidade*>* adj)
{
	adjascentes = adj;
	nome = N;
	distancia = dist;
	caminho = "";
	custo =  numeric_limits<float>::max();
	conhecido = false;
}


Cidade::~Cidade(void)
{
}

void Cidade::includeAdjascentes(Cidade* pCidade)
{
	adjascentes->include(pCidade);
}

string Cidade::getNome() const
{
	return nome;
}


void Cidade::setCusto(const float cCusto)
{
	custo = cCusto;
}

void Cidade::setCaminho(const string cCaminho)
{
	caminho = cCaminho;
}

void Cidade::setConhecido(bool cConhecido)
{
	conhecido = cConhecido;
}

float Cidade::getCusto() const
{
	return custo;
}

string Cidade::getCaminho() const
{
	return caminho;
}

bool Cidade::getConhecido() const
{
	return conhecido;
}

List<Cidade*>* Cidade::getAdjascentes()
{
	return adjascentes;
}

float Cidade::getDistancia()
{
	return distancia;
}

