#pragma once
#include "List.h"
class Cidade
{
private:
	List<Cidade*>* adjascentes;
	string nome;
	float distancia;

	bool conhecido;
	float custo;
	string caminho;

public:
	Cidade(string N = "Sem nome", float dist = 0, List<Cidade*>* adj = new List<Cidade*>);
	~Cidade(void);

	void includeAdjascentes(Cidade* pCidade);

	string getNome() const;

	void setCusto(const float cCusto);
	void setCaminho(const string cCaminho);
	void setConhecido(bool cConhecido);

	float getCusto() const;
	string getCaminho() const;
	bool getConhecido() const;
	float getDistancia();

	List<Cidade*>* getAdjascentes();

};

