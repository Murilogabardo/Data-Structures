#include "StdAfx.h"
#include "Grafo.h"


Grafo::Grafo(void)
{
	pVertical = NULL;
	pHorizontal = NULL;
}


Grafo::~Grafo(void)
{

}

Cidade* Grafo::adicionarCidade(Cidade* pCidade)
{
	listaVertical.include(pCidade);
	return pAux;
}
void Grafo::adicionarAdjascente(Cidade* pCidade, string Name, float Distancia)
{
	pAux = listaVertical.search(pCidade);
	pAux->includeAdjascentes(new Cidade(Name,Distancia));
}

void Grafo::calcularDistanciasMinimas(string Raiz)	
{
	
	bool rodar;
	bool primeira = true;
	float distancia;
	float min;

	int k, i, j;

	pVertical = procurar(Raiz);
	pVertical->setCusto(0);

	do
	{
		if(!primeira)
		{
			pVertical = procurar((*listHorizontal)[k]->getNome());
		}
		else
		{
			primeira = false;
		}

		listHorizontal = pVertical->getAdjascentes();

		pVertical->setConhecido(true);
		rodar = false;
		min = numeric_limits<float>::max();


		for(i = 0; i < listHorizontal->getListSize(); i++)
		{
			pHorizontal = (*listHorizontal)[i];
			pAux = procurar(pHorizontal->getNome());
			distancia = pHorizontal->getDistancia();
			
			if(pHorizontal->getNome() != Raiz)
			{
				if((distancia +  pVertical->getCusto()) < pAux->getCusto() && !pAux->getConhecido())
				{
					pAux->setCusto(distancia +  pVertical->getCusto());
					pAux->setCaminho(pVertical->getNome());
				}

				if(distancia < min && !pAux->getConhecido())
				{
					k = i;
					min = distancia;
					rodar = true;
				}
			}
		}

	}while(rodar);
}

void Grafo::imprimirDistanciaMinima(string Destino)
{
	cout<<procurar(Destino)->getCusto();
}

Cidade* Grafo::procurar(string Nome)
{
	int i;
	for(i = 0; i < listaVertical.getListSize(); i++)
	{
		if(listaVertical[i]->getNome() == Nome)
		{
			return listaVertical[i];
		}
	}
}

int Grafo::getNumeroCidades() const
{
	return listaVertical.getListSize();
}

Cidade* Grafo::operator[] (const int posicao)
{
	return listaVertical[posicao];
}
