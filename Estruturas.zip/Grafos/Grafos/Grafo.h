#pragma once

#include "List.h"
#include "stdafx.h"
#include "Cidade.h"

class Grafo
{

private:

	List<Cidade*> listaVertical;
	List<Cidade*>* pListaCorrida;
	List<Cidade*>* listHorizontal;
	Cidade* pVertical;
	Cidade* pHorizontal;
	Cidade* pAux;


public:
	Grafo(void);
	~Grafo(void);

	Cidade* adicionarCidade(Cidade* pCidade);
	void adicionarAdjascente(Cidade* pCidade, string Name, float Distancia);
	void calcularDistanciasMinimas(string Raiz);
	void imprimirDistanciaMinima(string Destino);
	int getNumeroCidades() const;
	Cidade* Grafo::operator[] (const int posicao);
	Cidade* procurar(string Nome);
};

