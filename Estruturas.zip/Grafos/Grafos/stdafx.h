// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <string>

using std::string;

#include "limits.h"

using std::numeric_limits;

#include <iostream>

using std::cout;
using std::cin;
using std::endl;



#include <stdio.h>
#include <tchar.h>



// TODO: reference additional headers your program requires here
